package register;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbConnection.ProvideConnection;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection con=ProvideConnection.getCon();
    private Statement updateStatement=null;
    private String updateQuery=null;
    String fatherName=null;
    String motherName=null;
    String mobileNo=null;
    String address=null;
    String gender=null;
    String course=null;
    String sem=null;
    String dob=null;
    String regno=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
   
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		fatherName=request.getParameter("fatherName");
		motherName=request.getParameter("motherName");
		mobileNo=request.getParameter("mobileno");
		address=request.getParameter("address");
		gender=request.getParameter("gender");
		course=request.getParameter("course");
		sem=request.getParameter("semester");
		updateQuery="update student set MobileNo='"+mobileNo+"',+FatherName='"+fatherName+"',MotherName='"+motherName+"',DOB='"+dob+"',"
				+ "Gender='"+gender+"',Course='"+course+"',Semester='"+sem+"',Address='"+address+"' where RegNo='"+regno+"';";
		//execute query
		try {
			updateStatement=con.createStatement();
			updateStatement.executeUpdate(updateQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("profile.html");
	}

}
