package login.signup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbConnection.ProvideConnection;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private String uname=null;
    private String password=null;
    private Connection con=null;
    Statement queryStatement=null;
    ResultSet result=null;
    private String query=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        con=ProvideConnection.getCon();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        response.setHeader("Cache-Control","no-cache,no-store,must-revalidate");
		uname=request.getParameter("regno");
		password=request.getParameter("password");
		query="select *from student where regno='"+uname+"' and password='"+password+"';";
		try {
			queryStatement=con.createStatement();
			result=queryStatement.executeQuery(query);
			if(result==null)
			{
				query="select *from Faculty where regid='"+uname+"' and password='"+password+"';";
				queryStatement=con.createStatement();
				result=queryStatement.executeQuery(query);
				if(result==null)
					response.sendRedirect("login.html");
				else
					response.sendRedirect("profileUpdate.html");
				
			}
			else
				response.sendRedirect("profileUpdate.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("login.html");
			e.printStackTrace();
		}

	}

}
